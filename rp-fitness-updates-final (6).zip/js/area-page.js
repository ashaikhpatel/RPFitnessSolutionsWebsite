/* ============================================================
   AREA PAGE — Dynamic Content Injector
   Reads the page's own filename to determine which area
   it is, then populates all text, SEO tags, and schema.
   ============================================================ */

/* ── Area Data ────────────────────────────────────────────── */
const AREA_DATA = {
  "chicago": {
    name: "Chicago",
    county: "Cook County",
    state: "IL",
    desc: "Chicago's premier fitness equipment repair service. We cover all Chicago neighborhoods — Lincoln Park, Wicker Park, Lakeview, Logan Square, Hyde Park, Pilsen, and more. Same-day service available citywide.",
    localFast: "Based in Niles, IL — bordering Chicago's northwest side — we can reach most Chicago neighborhoods within 30 minutes. Same-day service is available across the city, 7 days a week.",
    faqA1: "Yes. We offer same-day fitness equipment repair across all Chicago neighborhoods. Call (773) 977-3004 by noon and we'll aim to have a technician with you the same day.",
    nearby: ["evanston", "skokie", "oak-park", "des-plaines", "cicero", "berwyn"],
  },
  "evanston": {
    name: "Evanston",
    county: "Cook County",
    state: "IL",
    desc: "Same-day fitness equipment repair in Evanston, IL. Treadmill, elliptical and exercise bike repair for Evanston homeowners and condo buildings. 90-day warranty on every repair.",
    localFast: "Evanston is a quick drive from our Niles base — we regularly provide same-day service to Evanston residents and can often respond within hours of your call.",
    faqA1: "Yes. We provide same-day fitness equipment repair in Evanston. Call us at (773) 977-3004 and we'll do our best to send a technician the same day, 7 days a week.",
    nearby: ["chicago", "skokie", "wilmette", "glenview", "park-ridge"],
  },
  "skokie": {
    name: "Skokie",
    county: "Cook County",
    state: "IL",
    desc: "Professional fitness equipment repair in Skokie, IL. Fast, reliable treadmill, elliptical and bike repair for Skokie residents and gym facilities. Parts at cost, 90-day warranty.",
    localFast: "Skokie is just minutes from our Niles base. We can typically offer same-day service to Skokie customers and carry commonly needed parts in our service van.",
    faqA1: "Yes. Same-day service is available in Skokie for most fitness equipment repairs. Call (773) 977-3004 early in the day for the best chance of same-day availability.",
    nearby: ["chicago", "evanston", "des-plaines", "glenview", "park-ridge", "niles"],
  },
  "des-plaines": {
    name: "Des Plaines",
    county: "Cook County",
    state: "IL",
    desc: "Fitness equipment repair in Des Plaines, IL. Expert treadmill, elliptical and exercise bike repair service for Des Plaines residents. Same-day service, 90-day warranty.",
    localFast: "Des Plaines is right next door to our Niles base — one of our closest service areas. We offer reliable same-day service to Des Plaines and respond fast.",
    faqA1: "Absolutely. Des Plaines is one of our closest service areas. Same-day fitness equipment repair is commonly available here — call (773) 977-3004 to book.",
    nearby: ["chicago", "skokie", "park-ridge", "arlington-heights", "palatine", "schaumburg"],
  },
  "arlington-heights": {
    name: "Arlington Heights",
    county: "Cook County",
    state: "IL",
    desc: "Fitness equipment repair in Arlington Heights, IL. Trusted treadmill, elliptical and home gym repair for Arlington Heights homeowners. No markup on parts. 90-day warranty.",
    localFast: "Arlington Heights is within easy reach from our Niles base. We regularly serve Arlington Heights residents and commercial facilities with same-day and next-day repair service.",
    faqA1: "Yes. We provide same-day and next-day fitness equipment repair in Arlington Heights. Call (773) 977-3004 to check same-day availability.",
    nearby: ["palatine", "schaumburg", "des-plaines", "glenview", "chicago"],
  },
  "schaumburg": {
    name: "Schaumburg",
    county: "Cook County",
    state: "IL",
    desc: "Fitness equipment repair in Schaumburg, IL. Same-day treadmill, elliptical and exercise bike repair for Schaumburg homes and commercial fitness centers. 90-day warranty guaranteed.",
    localFast: "Schaumburg is well within our core service area from Niles. We regularly handle same-day repairs for Schaumburg residents and can often accommodate urgent requests.",
    faqA1: "Yes. Same-day fitness equipment repair is available in Schaumburg. Call (773) 977-3004 to book — we'll check our same-day schedule and get you on it.",
    nearby: ["arlington-heights", "des-plaines", "palatine", "elgin", "bolingbrook"],
  },
  "naperville": {
    name: "Naperville",
    county: "DuPage County",
    state: "IL",
    desc: "Fitness equipment repair in Naperville, IL. Professional treadmill, elliptical, and home gym repair for Naperville residents. 90-day warranty. Parts at cost, no markup.",
    localFast: "Naperville is a roughly 40-minute drive from our Niles base — within our standard service area. We serve Naperville regularly and offer next-day and often same-day service.",
    faqA1: "Yes. We serve Naperville with same-day and next-day fitness equipment repair. Call (773) 977-3004 to check availability — Naperville is within our standard service area.",
    nearby: ["bolingbrook", "aurora", "downers-grove", "lombard", "schaumburg"],
  },
  "oak-park": {
    name: "Oak Park",
    county: "Cook County",
    state: "IL",
    desc: "Fitness equipment repair in Oak Park, IL. Reliable treadmill, elliptical, and exercise bike repair for Oak Park homes and buildings. Same-day service available.",
    localFast: "Oak Park is easily accessible from our Niles location. We serve Oak Park homeowners and condo buildings regularly, with same-day service available most days.",
    faqA1: "Yes. Same-day service is commonly available in Oak Park. Call (773) 977-3004 — Oak Park is well within our primary service zone.",
    nearby: ["chicago", "cicero", "berwyn", "evanston", "des-plaines"],
  },
  "glenview": {
    name: "Glenview",
    county: "Cook County",
    state: "IL",
    desc: "Fitness equipment repair in Glenview, IL. Expert treadmill, elliptical and home gym repair for Glenview residents. Fast response, 90-day warranty, no parts markup.",
    localFast: "Glenview is very close to our Niles base. We provide fast response times in Glenview and same-day service is available on most days of the week.",
    faqA1: "Yes. Glenview is one of our fastest-response areas. Same-day service is usually available — call (773) 977-3004 early to secure your spot.",
    nearby: ["skokie", "evanston", "wilmette", "des-plaines", "arlington-heights"],
  },
  "wilmette": {
    name: "Wilmette",
    county: "Cook County",
    state: "IL",
    desc: "Fitness equipment repair in Wilmette, IL. Professional repair of treadmills, ellipticals and exercise bikes for Wilmette homeowners. Same-day service, 90-day warranty.",
    localFast: "Wilmette is a short drive from Niles along the north shore corridor. We provide quick, reliable service to Wilmette with same-day availability most days.",
    faqA1: "Yes. We provide same-day fitness equipment repair in Wilmette. Call (773) 977-3004 to check availability for your area.",
    nearby: ["evanston", "glenview", "skokie", "chicago", "park-ridge"],
  },
  "palatine": {
    name: "Palatine",
    county: "Cook County",
    state: "IL",
    desc: "Fitness equipment repair in Palatine, IL. Same-day treadmill, elliptical and exercise bike repair for Palatine homeowners and fitness facilities. 90-day warranty included.",
    localFast: "Palatine is within our regular service zone from Niles. We serve Palatine frequently and offer same-day service for most repair requests.",
    faqA1: "Yes. Same-day service is available in Palatine. Call (773) 977-3004 to book your repair — Palatine is a regular stop in our service schedule.",
    nearby: ["arlington-heights", "schaumburg", "des-plaines", "elgin"],
  },
  "bolingbrook": {
    name: "Bolingbrook",
    county: "Will County",
    state: "IL",
    desc: "Fitness equipment repair in Bolingbrook, IL. Treadmill, elliptical and home gym repair for Bolingbrook residents. Same-day and next-day service. 90-day warranty.",
    localFast: "Bolingbrook is in the southwest suburbs, about 35 minutes from Niles. We serve Bolingbrook regularly and provide same-day or next-day service for most repair requests.",
    faqA1: "Yes. We service Bolingbrook with same-day and next-day options. Call (773) 977-3004 — we'll find the fastest available appointment for you.",
    nearby: ["naperville", "joliet", "aurora", "downers-grove", "lombard"],
  },
  "joliet": {
    name: "Joliet",
    county: "Will County",
    state: "IL",
    desc: "Fitness equipment repair in Joliet, IL. Professional treadmill, elliptical and exercise bike repair service in Joliet. 90-day warranty on all repairs.",
    localFast: "Joliet is at the edge of our service radius, about 55km from Niles. We serve Joliet customers and can arrange next-day and often same-day appointments.",
    faqA1: "Yes. We service Joliet within our extended coverage area. Same-day is subject to scheduling, but next-day service is reliably available. Call (773) 977-3004.",
    nearby: ["bolingbrook", "naperville", "aurora", "tinley-park", "orland-park"],
  },
  "aurora": {
    name: "Aurora",
    county: "Kane County",
    state: "IL",
    desc: "Fitness equipment repair in Aurora, IL. Expert repair of treadmills, ellipticals and exercise bikes in Aurora. 90-day warranty guaranteed on all work.",
    localFast: "Aurora is within our extended service zone from Niles. We serve Aurora customers and typically offer next-day service with same-day available for urgent requests.",
    faqA1: "Yes. We cover Aurora for fitness equipment repair. Call (773) 977-3004 and we'll find the quickest available slot — next-day service is standard for Aurora.",
    nearby: ["naperville", "bolingbrook", "elgin", "schaumburg", "lombard"],
  },
  "waukegan": {
    name: "Waukegan",
    county: "Lake County",
    state: "IL",
    desc: "Fitness equipment repair in Waukegan, IL. Trusted treadmill, elliptical and home gym repair service in Waukegan and Lake County. 90-day warranty.",
    localFast: "Waukegan is in the northern part of our service area, about 45 minutes from Niles. We serve Waukegan and provide reliable next-day service with same-day on request.",
    faqA1: "Yes. We cover Waukegan for fitness equipment repair. Call (773) 977-3004 to schedule — we serve the Lake County area regularly.",
    nearby: ["chicago", "evanston", "glenview", "wilmette", "arlington-heights"],
  },
  "elgin": {
    name: "Elgin",
    county: "Kane County",
    state: "IL",
    desc: "Fitness equipment repair in Elgin, IL. Professional treadmill, elliptical and exercise bike repair in Elgin. Same-day and next-day service. 90-day warranty.",
    localFast: "Elgin is in the far northwest suburbs, about 50 minutes from Niles. We serve Elgin and can arrange same-day and next-day appointments to suit your schedule.",
    faqA1: "Yes. We provide fitness equipment repair in Elgin. Call (773) 977-3004 — next-day is standard and same-day is often possible if you call before noon.",
    nearby: ["schaumburg", "palatine", "arlington-heights", "aurora"],
  },
  "tinley-park": {
    name: "Tinley Park",
    county: "Cook County",
    state: "IL",
    desc: "Fitness equipment repair in Tinley Park, IL. Reliable treadmill, elliptical and exercise bike repair in Tinley Park. 90-day warranty and no markup on parts.",
    localFast: "Tinley Park is in the south suburbs, about 40 minutes from Niles. We service Tinley Park regularly and can often accommodate same-day requests.",
    faqA1: "Yes. We cover Tinley Park for fitness equipment repair. Call (773) 977-3004 — same-day is often available and next-day is always an option.",
    nearby: ["orland-park", "joliet", "bolingbrook", "oak-lawn", "chicago"],
  },
  "oak-lawn": {
    name: "Oak Lawn",
    county: "Cook County",
    state: "IL",
    desc: "Fitness equipment repair in Oak Lawn, IL. Expert treadmill, elliptical and bike repair in Oak Lawn. Same-day available. 90-day warranty on every repair.",
    localFast: "Oak Lawn is in the southwest Cook County suburbs, easily reachable from Niles. Same-day service is commonly available for Oak Lawn customers.",
    faqA1: "Yes. Same-day fitness equipment repair is often available in Oak Lawn. Call (773) 977-3004 to book your appointment.",
    nearby: ["chicago", "cicero", "berwyn", "tinley-park", "orland-park"],
  },
  "orland-park": {
    name: "Orland Park",
    county: "Cook County",
    state: "IL",
    desc: "Fitness equipment repair in Orland Park, IL. Trusted treadmill, elliptical and home gym repair in Orland Park. 90-day warranty, parts at cost.",
    localFast: "Orland Park is about 45 minutes from Niles in the south suburbs. We serve Orland Park regularly with next-day service and same-day for urgent needs.",
    faqA1: "Yes. We cover Orland Park for fitness equipment repair. Next-day service is standard; same-day may be available. Call (773) 977-3004 to find out.",
    nearby: ["tinley-park", "joliet", "oak-lawn", "bolingbrook"],
  },
  "park-ridge": {
    name: "Park Ridge",
    county: "Cook County",
    state: "IL",
    desc: "Fitness equipment repair in Park Ridge, IL. Professional treadmill, elliptical and exercise bike repair in Park Ridge. Same-day available, 90-day warranty.",
    localFast: "Park Ridge is right next door to Niles — one of our closest service areas. We can often offer same-day service with a very fast response time for Park Ridge customers.",
    faqA1: "Yes. Park Ridge is one of our closest service areas to our Niles base. Same-day fitness equipment repair is commonly available. Call (773) 977-3004.",
    nearby: ["des-plaines", "skokie", "chicago", "glenview", "evanston"],
  },
  "lombard": {
    name: "Lombard",
    county: "DuPage County",
    state: "IL",
    desc: "Fitness equipment repair in Lombard, IL. Reliable treadmill, elliptical and home gym repair in Lombard, DuPage County. 90-day warranty guaranteed.",
    localFast: "Lombard is in DuPage County, about 35 minutes from Niles. We serve Lombard regularly and offer same-day and next-day service depending on availability.",
    faqA1: "Yes. We cover Lombard for fitness equipment repair. Same-day and next-day options are available. Call (773) 977-3004 to book.",
    nearby: ["naperville", "downers-grove", "aurora", "bolingbrook", "schaumburg"],
  },
  "downers-grove": {
    name: "Downers Grove",
    county: "DuPage County",
    state: "IL",
    desc: "Fitness equipment repair in Downers Grove, IL. Expert treadmill, elliptical and exercise bike repair in Downers Grove. 90-day warranty, no parts markup.",
    localFast: "Downers Grove is in the western suburbs, about 40 minutes from Niles. We serve Downers Grove homeowners and commercial facilities with reliable repair service.",
    faqA1: "Yes. We provide fitness equipment repair in Downers Grove. Same-day is subject to availability; next-day is always possible. Call (773) 977-3004.",
    nearby: ["lombard", "naperville", "bolingbrook", "aurora", "schaumburg"],
  },
  "cicero": {
    name: "Cicero",
    county: "Cook County",
    state: "IL",
    desc: "Fitness equipment repair in Cicero, IL. Same-day treadmill, elliptical and bike repair in Cicero. Professional service, 90-day warranty, parts at cost.",
    localFast: "Cicero is a short drive from Niles via I-90. We provide fast same-day service to Cicero customers and keep our schedule flexible to accommodate urgent repairs.",
    faqA1: "Yes. Same-day fitness equipment repair is available in Cicero. Call (773) 977-3004 early in the day to lock in a same-day slot.",
    nearby: ["chicago", "oak-park", "berwyn", "oak-lawn"],
  },
  "berwyn": {
    name: "Berwyn",
    county: "Cook County",
    state: "IL",
    desc: "Fitness equipment repair in Berwyn, IL. Professional treadmill, elliptical and home gym repair in Berwyn. Same-day available. 90-day warranty included.",
    localFast: "Berwyn is easily reachable from our Niles base. We serve Berwyn homeowners and provide same-day service most days of the week.",
    faqA1: "Yes. Same-day service is commonly available in Berwyn. Call (773) 977-3004 to check today's schedule and book your repair.",
    nearby: ["chicago", "cicero", "oak-park", "oak-lawn"],
  },
  "niles": {
    name: "Niles",
    county: "Cook County",
    state: "IL",
    desc: "RP Fitness Solutions is based right here in Niles, IL. We offer the fastest response times in Niles for treadmill, elliptical and exercise bike repair. 90-day warranty on every job.",
    localFast: "Niles is our home base at 8047 W Davis St. We can respond to Niles repair requests faster than any other area — often within hours of your call.",
    faqA1: "Yes. Being based in Niles, we can offer the fastest same-day response in the area. Call (773) 977-3004 to book.",
    nearby: ["park-ridge", "des-plaines", "skokie", "glenview", "chicago"],
  },
  "barrington": {
    name: "Barrington",
    county: "Cook/Lake County",
    state: "IL",
    desc: "Fitness equipment repair in Barrington, IL. Professional treadmill, elliptical and home gym repair for Barrington homeowners and facilities. 90-day warranty guaranteed.",
    localFast: "Barrington is in the northwest suburbs, about 40 minutes from our Niles base. We serve Barrington regularly with reliable same-day and next-day service.",
    faqA1: "Yes. We serve Barrington for fitness equipment repair. Call (773) 977-3004 to schedule — same-day and next-day options are available.",
    nearby: ["elgin", "palatine", "arlington-heights", "schaumburg"],
  },
  "west-chicago": {
    name: "West Chicago",
    county: "DuPage County",
    state: "IL",
    desc: "Fitness equipment repair in West Chicago, IL. Expert treadmill, elliptical and exercise bike repair in West Chicago. 90-day warranty, parts at cost.",
    localFast: "West Chicago is in DuPage County, about 35 minutes from Niles. We serve West Chicago customers with same-day and next-day repair appointments.",
    faqA1: "Yes. We cover West Chicago for fitness equipment repair. Call (773) 977-3004 — same-day and next-day options available.",
    nearby: ["elgin", "aurora", "lombard", "naperville", "downers-grove"],
  },
  "westmont": {
    name: "Westmont",
    county: "DuPage County",
    state: "IL",
    desc: "Fitness equipment repair in Westmont, IL. Reliable treadmill, elliptical and home gym repair in Westmont, DuPage County. 90-day warranty on all repairs.",
    localFast: "Westmont is in the western suburbs, about 35 minutes from Niles. We serve Westmont homeowners and commercial facilities with professional on-site repair.",
    faqA1: "Yes. We service Westmont for fitness equipment repair. Same-day is often available — call (773) 977-3004 to check today's schedule.",
    nearby: ["lombard", "downers-grove", "naperville", "bolingbrook", "oak-lawn"],
  },
  "bridgeview": {
    name: "Bridgeview",
    county: "Cook County",
    state: "IL",
    desc: "Fitness equipment repair in Bridgeview, IL. Professional treadmill, elliptical and exercise bike repair in Bridgeview. 90-day warranty, no markup on parts.",
    localFast: "Bridgeview is in the southwest Cook County suburbs, accessible from Niles. We provide prompt service to Bridgeview homeowners and commercial facilities.",
    faqA1: "Yes. We cover Bridgeview for fitness equipment repair. Call (773) 977-3004 to check same-day availability.",
    nearby: ["oak-lawn", "cicero", "chicago", "tinley-park", "orland-park"],
  },
  "north-shore": {
    name: "North Shore",
    county: "Cook/Lake County",
    state: "IL",
    desc: "Fitness equipment repair on Chicago's North Shore, IL. Expert repair of treadmills, ellipticals and exercise bikes in Winnetka, Glencoe, Highland Park and surrounding areas.",
    localFast: "The North Shore communities are well within our service area from Niles. We serve Winnetka, Glencoe, Highland Park, Lake Forest and surrounding areas with reliable same-day and next-day service.",
    faqA1: "Yes. We service all North Shore communities for fitness equipment repair. Call (773) 977-3004 — next-day service is standard and same-day is often available.",
    nearby: ["evanston", "wilmette", "glenview", "waukegan", "chicago"],
  },
};

/* ── Initialize ───────────────────────────────────────────── */
(function init() {
  // Detect slug from filename
  const slug = location.pathname
    .split("/").pop()
    .replace(".html", "")
    .toLowerCase();

  const area = AREA_DATA[slug];
  if (!area) return; // template view — no data, don't crash

  const { name, county, state, desc, localFast, faqA1, nearby } = area;

  // ── SEO Head ──────────────────────────────────────────────
  const title = `Fitness Equipment Repair ${name} IL | Same-Day | RP Fitness Solutions`;
  document.title = title;
  setMeta("meta-desc",    `${name}'s trusted fitness equipment repair. Same-day treadmill, elliptical & exercise bike repair in ${name}, ${state}. 90-day warranty. Call (773) 977-3004.`);
  setMeta("meta-keywords",`fitness equipment repair ${name}, treadmill repair ${name} IL, elliptical repair ${name}, exercise bike repair ${name} IL, gym equipment repair ${name}`);
  setEl("canonical",     "href", `https://www.rpfitnesssolutions.com/areas/${slug}.html`);
  setEl("og-url",        "content", `https://www.rpfitnesssolutions.com/areas/${slug}.html`);
  setEl("og-title",      "content", title);
  setEl("og-desc",       "content", `${name}'s trusted fitness equipment repair. Same-day service. 90-day warranty. Serving ${name} IL and surrounding areas.`);

  // ── LocalBusiness Schema ───────────────────────────────────
  const schema = {
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    "name": `RP Fitness Solutions — ${name}`,
    "description": `Fitness equipment repair in ${name}, ${state}. Same-day treadmill, elliptical and exercise bike repair.`,
    "url": `https://www.rpfitnesssolutions.com/areas/${slug}.html`,
    "telephone": "+17739773004",
    "email": "rpfitnesssolutions@gmail.com",
    "address": {
      "@type": "PostalAddress",
      "streetAddress": "8047 W Davis St",
      "addressLocality": "Niles",
      "addressRegion": "IL",
      "postalCode": "60714",
      "addressCountry": "US"
    },
    "areaServed": {
      "@type": "City",
      "name": name,
      "addressRegion": state
    },
    "aggregateRating": {
      "@type": "AggregateRating",
      "ratingValue": "5",
      "bestRating": "5",
      "ratingCount": "150"
    }
  };
  document.getElementById("schema-local").textContent = JSON.stringify(schema, null, 2);

  // ── Body Content ───────────────────────────────────────────
  // Top bar
  setText("tb-area", name.toUpperCase());

  // Breadcrumb
  setText("bc-area", name);

  // Hero
  setText("hero-eyebrow", `Serving ${name}, ${state}`);
  setText("hero-h1", `Fitness Equipment Repair in ${name}, IL`);
  setText("hero-desc", desc);

  // Services section
  setText("services-eyebrow", `Services in ${name}`);
  setText("services-h2",      `Equipment Repair Services in ${name}, IL`);
  setText("services-desc",    `Professional on-site repair, assembly and maintenance in ${name}. We come to you — no dropoff required.`);

  // Replace [Area] placeholders in all service cards
  document.querySelectorAll(".service-card p, .service-card h3").forEach(el => {
    el.innerHTML = el.innerHTML.replace(/\[Area\]/g, name);
  });

  // Why Local
  setText("local-eyebrow", `Why ${name} Chooses AP`);
  setText("local-h2",      `The #1 Choice for Fitness Repair in ${name}`);
  setText("local-fast",    localFast);

  // FAQ
  setText("faq-eyebrow", `FAQ — ${name}`);
  setText("faq-h2",      `Common Questions from ${name} Customers`);
  setText("faq-q1",      `Do you offer same-day fitness equipment repair in ${name}?`);
  setText("faq-a1",      faqA1);

  // Replace remaining [Area] placeholders anywhere
  document.querySelectorAll("p, h2, h3, h4, span, li").forEach(el => {
    if (el.children.length === 0 && el.textContent.includes("[Area]")) {
      el.textContent = el.textContent.replace(/\[Area\]/g, name);
    }
  });

  // Nearby areas
  const nearbyChips = document.getElementById("nearby-chips");
  setText("nearby-h2", `Nearby Areas We Also Service from ${name}`);
  if (nearbyChips && nearby) {
    nearbyChips.innerHTML = nearby.map(slug => {
      const a = AREA_DATA[slug];
      if (!a) return "";
      return `<a href="${slug}.html" class="area-chip">${a.name}, IL</a>`;
    }).join("");
  }

  // Footer areas
  const footerAreas = document.getElementById("footer-areas");
  if (footerAreas) {
    const all = Object.keys(AREA_DATA).slice(0, 8);
    footerAreas.innerHTML = all.map(s => {
      const a = AREA_DATA[s];
      return `<li><a href="${s}.html">${a.name}</a></li>`;
    }).join("");
  }

  // Footer copyright
  setText("footer-copy", `© 2025 RP Fitness Solutions. Serving ${name}, IL and Chicagoland.`);

  // CTA section
  setText("cta-h2", `Need Fitness Equipment Repair in ${name}?`);

  // Page title tag
  document.getElementById("page-title").textContent = title;
})();

/* ── Helpers ──────────────────────────────────────────────── */
function setText(id, val) {
  const el = document.getElementById(id);
  if (el) el.textContent = val;
}
function setEl(id, attr, val) {
  const el = document.getElementById(id);
  if (el) el.setAttribute(attr, val);
}
function setMeta(id, val) {
  const el = document.getElementById(id);
  if (el) el.setAttribute("content", val);
}
