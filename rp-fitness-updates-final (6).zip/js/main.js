/* ============================================================
   RP FITNESS SOLUTIONS — CHICAGO
   ============================================================ */

const SITE = {
  name:     "RP Fitness Solutions",
  phone:    "+17739773004",
  phoneFmt: "(773) 977-3004",
  email:    "rpfitnesssolutions@gmail.com",
};

document.addEventListener("DOMContentLoaded", () => {
  initNav();
  initScrollAnimations();
  initForm();
});

/* ── Navigation ───────────────────────────────────────────── */
function initNav() {
  const nav    = document.querySelector(".nav");
  const toggle = document.getElementById("nav-toggle");
  const links  = document.getElementById("nav-links");

  if (nav) {
    window.addEventListener("scroll", () => {
      nav.classList.toggle("scrolled", window.scrollY > 60);
    }, { passive: true });
  }

  if (toggle && links) {
    toggle.addEventListener("click", () => {
      const open = toggle.classList.toggle("active");
      links.classList.toggle("mobile-open", open);
    });
    links.querySelectorAll("a").forEach(a => {
      a.addEventListener("click", () => {
        toggle.classList.remove("active");
        links.classList.remove("mobile-open");
      });
    });
  }
}

/* ── Scroll reveal ────────────────────────────────────────── */
function initScrollAnimations() {
  if (!("IntersectionObserver" in window)) return;
  const io = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.style.opacity = "1";
        e.target.style.transform = "translateY(0)";
        io.unobserve(e.target);
      }
    });
  }, { threshold: 0.08 });

  document.querySelectorAll(".reveal").forEach(el => {
    el.style.opacity = "0";
    el.style.transform = "translateY(20px)";
    el.style.transition = "opacity 0.5s ease, transform 0.5s ease";
    io.observe(el);
  });
}

/* ── Form — Web3Forms silent POST ─────────────────────────── */
function initForm() {
  const form = document.getElementById("quote-form");
  if (!form) return;

  const btn = form.querySelector(".form-submit");

  // Inject Web3Forms hidden fields
  [
    ["access_key", "fab130c4-98b8-400d-b87f-6dedb77d7ab6"],
    ["subject",    "New Enquiry — RP Fitness Solutions Chicago"],
    ["redirect",   "false"],
  ].forEach(([name, value]) => {
    const input = Object.assign(document.createElement("input"), {
      type: "hidden", name, value
    });
    form.appendChild(input);
  });

  // Message box
  const msg = Object.assign(document.createElement("div"), {
    id: "form-msg"
  });
  msg.style.cssText = "display:none;padding:14px 18px;border-radius:6px;font-family:var(--font-ui);font-size:0.88rem;margin-bottom:20px;line-height:1.5;font-weight:500;";
  form.prepend(msg);

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const phoneEl = form.querySelector("[name='phone']");
    if (!phoneEl?.value.trim()) {
      showMsg(msg, "error", "Please enter your phone number so we can reach you.");
      phoneEl?.focus();
      return;
    }

    btn.disabled    = true;
    btn.textContent = "Sending…";
    msg.style.display = "none";

    try {
      const res  = await fetch("https://api.web3forms.com/submit", {
        method: "POST",
        body:   new FormData(form),
        headers: { Accept: "application/json" },
      });
      const json = await res.json();

      if (json.success) {
        showMsg(msg, "success", "✓  Message sent! We'll be in touch shortly.");
        form.reset();
        btn.textContent      = "Message Sent ✓";
        btn.style.background = "#2D6A4F";
        setTimeout(() => {
          btn.textContent      = "Send Message";
          btn.style.background = "";
          btn.disabled         = false;
        }, 5000);
      } else {
        throw new Error(json.message || "Submission failed");
      }
    } catch {
      showMsg(msg, "error", "Something went wrong. Please call us at " + SITE.phoneFmt + ".");
      btn.textContent = "Send Message";
      btn.disabled    = false;
    }
  });
}

function showMsg(box, type, text) {
  box.textContent   = text;
  box.style.display = "block";
  const ok = type === "success";
  box.style.background = ok ? "#ECFDF5" : "#FEF2F2";
  box.style.color      = ok ? "#065F46" : "#991B1B";
  box.style.border     = ok ? "1px solid #A7F3D0" : "1px solid #FECACA";
}
